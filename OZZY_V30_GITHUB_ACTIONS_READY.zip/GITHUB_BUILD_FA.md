# ساخت OZZY با GitHub Actions

1. کل محتوای این پوشه را داخل یک Repository در GitHub قرار دهید.
2. به تب Actions بروید.
3. Workflow با نام `Build OZZY Desktop and Android` را انتخاب کنید.
4. گزینه `Run workflow` را بزنید.
5. پس از موفقیت، از بخش Artifacts فایل‌های `OZZY-Android-APK` و `OZZY-Windows` را دانلود کنید.

این Workflow کلید API یا Secret را داخل Repository قرار نمی‌دهد.
