# OZZY V30 — Native Windows + Android

این نسخه، رابط OZZY V29 را به دو پوستهٔ بومی تبدیل می‌کند:

- Windows: Electron → خروجی `.exe` / Installer
- Android: Native WebView → خروجی `.apk`

## نکته مهم
در محیط فعلی ساخت نهایی Windows/Android به toolchain مخصوص هر پلتفرم وابسته است. بنابراین این بسته **پروژه‌های قابل Build** را آماده می‌کند؛ برای تولید فایل نهایی، روی Windows از Node/Electron و روی Android از Android Studio/SDK استفاده کنید، یا workflow گیت‌هاب را اجرا کنید.

## Windows
```powershell
cd windows
npm install
npm run make
```
خروجی در `windows/out/make` ساخته می‌شود.

## Android
پروژه `android` را با Android Studio باز کنید و `Build > Generate App Bundles or APKs > Generate APKs` را بزنید.
یا با Gradle 8.7+:
```bash
cd android
gradle assembleDebug
```
APK در `android/app/build/outputs/apk/debug/` خواهد بود.

## امنیت
این پوسته‌ها UI فعلی را بسته‌بندی می‌کنند. کلیدهای API نباید داخل APK/EXE قرار بگیرند؛ برای معاملات واقعی Backend امن، least privilege، تأیید نهایی، Max Loss و Kill Switch باید فعال باشند.
