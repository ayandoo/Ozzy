module.exports = {
  packagerConfig: { name:'OZZY', executableName:'OZZY', appBundleId:'com.ozzy.ai.trading', asar:true },
  makers: [
    { name:'@electron-forge/maker-squirrel', config:{name:'OZZYAITrading'} },
    { name:'@electron-forge/maker-zip', platforms:['win32'] }
  ]
};
