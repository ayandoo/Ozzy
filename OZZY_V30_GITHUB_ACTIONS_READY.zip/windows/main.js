const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
function createWindow(){
  const win = new BrowserWindow({
    width: 1600, height: 1000, minWidth: 1100, minHeight: 700,
    backgroundColor: '#020611', autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, sandbox: true }
  });
  win.loadFile(path.join(__dirname,'index.html'));
  win.webContents.setWindowOpenHandler(({url})=>{
    if(/^https?:/.test(url)) shell.openExternal(url);
    return {action:'deny'};
  });
}
app.whenReady().then(()=>{ Menu.setApplicationMenu(null); createWindow(); app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0) createWindow();}); });
app.on('window-all-closed',()=>{if(process.platform!=='darwin') app.quit();});
