@echo off
cd /d "%~dp0android"
gradle assembleDebug
pause
