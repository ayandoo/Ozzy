@echo off
cd /d "%~dp0windows"
npm install
npm run make
pause
